<?php

use Illuminate\Database\Seeder;
use App\Category;
class CategoryTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
     public function run()
    {
       DB::table('categories')->truncate();
        $categories = array(
         array('id' => '1','name' => 'خشکبار','photo' => '1515659008driedfoods.jpg','maincat_id' => '1','created_at' => '2017-12-28 20:56:32','updated_at' => '2018-01-11 15:23:28'),
         array('id' => '2','name' => 'ادویه‌جات','photo' => '1515659364spices.jpg','maincat_id' => '1','created_at' => '2017-12-28 20:56:32','updated_at' => '2018-01-11 15:29:24'),
         array('id' => '3','name' => 'عرقیجات','photo' => '1515659379aromas.jpg','maincat_id' => '1','created_at' => '2017-12-28 20:56:32','updated_at' => '2018-01-11 15:29:39'),
         array('id' => '4','name' => 'عسل‌ها','photo' => '1515659394honey.jpg','maincat_id' => '1','created_at' => '2017-12-28 20:56:32','updated_at' => '2018-01-11 15:29:54'),
         array('id' => '5','name' => 'شیره','photo' => '1515659405juice.jpg','maincat_id' => '1','created_at' => '2017-12-28 20:56:32','updated_at' => '2018-01-11 15:30:05'),
         array('id' => '6','name' => 'روغن‌ها','photo' => '1515659421oil.jpg','maincat_id' => '1','created_at' => '2017-12-28 20:56:32','updated_at' => '2018-01-11 15:30:21'),
         array('id' => '7','name' => 'چای لاهیجان','photo' => '1515659434tea.jpg','maincat_id' => '1','created_at' => '2017-12-28 20:56:32','updated_at' => '2018-01-11 15:30:34'),
         array('id' => '9','name' => 'محصولات چوبی','photo' => '1515830200wooden.jpg','maincat_id' => '2','created_at' => '2017-12-28 20:56:32','updated_at' => '2018-01-13 14:56:40'),
         array('id' => '10','name' => 'دستباف و دست دوز','photo' => '1515830902dastbaft.jpg','maincat_id' => '2','created_at' => '2018-01-13 15:08:22','updated_at' => '2018-01-13 15:38:08'),
         array('id' => '11','name' => 'زیورآلات','photo' => '1515832710jewelry.jpg','maincat_id' => '2','created_at' => '2018-01-13 15:38:30','updated_at' => '2018-01-13 15:38:30'),
         array('id' => '12','name' => 'ترشیجات','photo' => '1516010644torshi.jpg','maincat_id' => '1','created_at' => '2018-01-15 17:04:04','updated_at' => '2018-01-15 17:04:04'),
         array('id' => '13','name' => 'دیگر محصولات سالم','photo' => '1516185477all.jpg','maincat_id' => '1','created_at' => '2018-01-17 17:37:57','updated_at' => '2018-01-17 17:37:57')
        );
            DB::table('categories')->insert($categories);
    }
}
